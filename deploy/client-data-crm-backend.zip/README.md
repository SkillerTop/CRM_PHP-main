# Client Data CRM — backend

Backend для CRM из `TZ_CRM_Client_Data_v3.1`: PHP 8.3, Apache + PHP-FPM, MySQL 8 и JSON REST API. Фронтенд намеренно не включён.

## Что реализовано

- вход по email/паролю, DB-сессии в `httpOnly` cookie, 12-часовой idle timeout, CSRF и rate limit;
- саморегистрация только как неактивный `Read-only` с подтверждением Admin;
- приглашение пользователя по ссылке или обязательный резервный сценарий с временным паролем;
- четыре роли: `admin`, `manager`, `editor`, `readonly`; права проверяются сервером при каждом запросе;
- профиль пользователя, смена email/пароля, завершение остальных сессий после смены пароля;
- Companies, Contacts и Tasks с фильтрами, сортировкой, пагинацией и серверной валидацией;
- optimistic locking по `updated_at` с HTTP 409;
- полный перерасчёт `Company.last_contact_date` при создании, редактировании и архивировании задач;
- комментарии, вложения до 20 МБ, мягкое удаление вложений, архивирование записей;
- единый append-only поток `change_events`: карточка задачи и Audit Log читают одну таблицу;
- Dashboard, Pipeline, глобальный поиск с `utf8mb4_0900_ai_ci`;
- планировщик напоминаний с catch-up, защитой от параллельной отправки, email и `.ics`;
- редактируемые справочники, Users & Roles, защита последнего активного Admin, Audit CSV;
- Postman-коллекция и окружение.

## Требования платформы

- PHP 8.3 NTS для PHP-FPM;
- расширения: `pdo_mysql`, `mbstring`, `json`, `openssl`, `fileinfo`;
- MySQL 8.0+ с InnoDB;
- Apache 2.4: `mod_rewrite`, `mod_proxy`, `mod_proxy_fcgi`, `setenvif`;
- cron/планировщик каждые 15 минут;
- SMTP relay или настроенный `mail()`; `MAIL_TRANSPORT=log` подходит только для разработки.

## Быстрый запуск

1. Скопируйте `.env.example` в `.env`, заполните БД, `APP_URL` и SMTP.
2. Создайте пустую MySQL-базу и пользователя с правами на неё.
3. Примените схему:

   ```bash
   php bin/console migrate
   ```

4. Укажите `ADMIN_NAME`, `ADMIN_EMAIL`, `ADMIN_PASSWORD` и создайте первого Admin:

   ```bash
   php bin/console create-admin
   ```

5. Направьте Apache `DocumentRoot` в каталог `public/` и выдайте PHP-FPM пользователю запись в `storage/logs` и `storage/uploads`.
6. Проверьте `GET /api/health`, затем импортируйте файлы из `postman/`.

Пароль первого администратора после входа требуется сменить. Значения `ADMIN_PASSWORD`, `DB_PASSWORD`, `SMTP_PASSWORD` и `FTP_PASSWORD` не должны попадать в Git или deploy-архив.

## Cron

```cron
*/15 * * * * cd /var/www/client-data-crm && /usr/bin/php bin/console reminders:run >> storage/logs/cron.log 2>&1
17 2 * * * cd /var/www/client-data-crm && /usr/bin/php bin/console cleanup >> storage/logs/cron.log 2>&1
```

Если хостинг допускает cron только раз в час, деактивируйте справочники `1 hour before` и `2 hours before`: они не смогут работать с заявленной точностью.

## Почта

- `MAIL_TRANSPORT=smtp` — встроенный SMTP-клиент с `tls`, `ssl` или без шифрования;
- `MAIL_TRANSPORT=mail` — системный `mail()`/sendmail;
- `MAIL_TRANSPORT=log` — письма пишутся в `storage/logs/mail.log`.

Недоступность SMTP не блокирует регистрацию или создание пользователя с временным паролем. Ошибка отправки напоминания записывается как `REMINDER FAILED`.

## Архивирование и вложения

Жёсткого удаления компаний, контактов и задач нет. Вложение при удалении скрывается через `deleted_at`, а физический файл остаётся до отдельной политики хранения/резервного копирования. Компания не архивируется, пока у неё есть открытые задачи.

## Развёртывание и FTP

- Apache/PHP-FPM пример: `deploy/apache-vhost.conf.example`.
- Сборка безопасного архива: `deploy/build-package.ps1`.
- Загрузка выполняется `deploy/ftp-deploy.ps1`; хост по умолчанию — `vs584.mirohost.net`, протокол — explicit FTPS.

Скрипт требует `FTP_USERNAME` и `FTP_PASSWORD` в окружении и не содержит секретов. Файл `.env` намеренно не загружается: создайте его на сервере через панель хостинга/защищённый канал.

## Резервные копии

Пример `deploy/backup.sh` создаёт ежедневный gzip-дамп MySQL и удаляет копии старше 30 дней. После настройки обязательно выполните тестовое восстановление в отдельную базу. Каталог `storage/uploads` также должен входить в файловую резервную копию.

## Формат API

Успех:

```json
{"data": {}, "meta": {}}
```

Ошибка:

```json
{"error":{"code":"validation_error","message":"Проверьте заполнение полей.","details":{"fields":{}}}}
```

Мутации после входа требуют cookie `crm_session` и заголовок `X-CSRF-Token`; токен возвращают login и `GET /api/auth/me`. Полный перечень маршрутов находится в [docs/API.md](docs/API.md).

