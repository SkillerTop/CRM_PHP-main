<?php

declare(strict_types=1);

namespace CRM\Controller;

use CRM\Http\Response;
use PDO;
use Throwable;

final class HealthController
{
    public function __construct(private readonly PDO $db)
    {
    }

    public function show(): never
    {
        try {
            $this->db->query('SELECT 1')->fetchColumn();
            Response::json(['data' => ['status' => 'ok', 'database' => 'ok']]);
        } catch (Throwable) {
            Response::json(['error' => ['code' => 'unhealthy', 'message' => 'Сервис временно недоступен.']], 503);
        }
    }
}
