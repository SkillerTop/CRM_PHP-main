from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request
from http.cookiejar import CookieJar


BASE_URL = os.environ.get("CRM_TEST_BASE_URL", "http://127.0.0.1:8088/api").rstrip("/")
ADMIN_EMAIL = os.environ.get("CRM_TEST_ADMIN_EMAIL", "admin@example.com")
ADMIN_PASSWORD = os.environ.get("CRM_TEST_ADMIN_PASSWORD", "AdminTest123!")


class Client:
    def __init__(self) -> None:
        self.jar = CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))
        self.csrf = ""

    def request(self, method: str, path: str, payload=None, expected=(200,)):
        headers = {"Accept": "application/json"}
        data = None
        if payload is not None:
            data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            headers["Content-Type"] = "application/json"
        if method not in {"GET", "HEAD", "OPTIONS"} and self.csrf:
            headers["X-CSRF-Token"] = self.csrf
        request = urllib.request.Request(BASE_URL + path, data=data, headers=headers, method=method)
        try:
            with self.opener.open(request, timeout=10) as response:
                status = response.status
                content_type = response.headers.get("Content-Type", "")
                raw = response.read()
        except urllib.error.HTTPError as error:
            status = error.code
            content_type = error.headers.get("Content-Type", "")
            raw = error.read()
        if status not in expected:
            raise AssertionError(f"{method} {path}: expected {expected}, got {status}: {raw.decode('utf-8', 'replace')}")
        if "application/json" in content_type:
            return status, json.loads(raw.decode("utf-8"))
        return status, raw

    def login(self, email: str, password: str) -> dict:
        _, body = self.request("POST", "/auth/login", {"email": email, "password": password})
        self.csrf = body["data"]["csrf_token"]
        return body["data"]["user"]


def lookup_id(data: dict, lookup_type: str, key: str) -> int:
    return next(item["id"] for item in data[lookup_type] if item["key"] == key)


def main() -> None:
    admin = Client()
    admin.request("GET", "/health")
    admin_user = admin.login(ADMIN_EMAIL, ADMIN_PASSWORD)
    assert admin_user["role"] == "admin"

    _, body = admin.request("GET", "/lookups")
    lookups = body["data"]
    company_type = lookup_id(lookups, "company_type", "shipyard")
    client_status = lookup_id(lookups, "client_status", "new_lead")
    contact_source = lookup_id(lookups, "contact_source", "exhibition")
    manager = lookup_id(lookups, "cjn_manager", "vitalii_vyshnevskyi")
    task_status = lookup_id(lookups, "task_status", "not_started")
    task_completed = lookup_id(lookups, "task_status", "completed")
    outcome = lookup_id(lookups, "outcome_status", "neutral")
    reminder = lookup_id(lookups, "reminder_lead_time", "one_day")

    suffix = str(int(time.time() * 1000))
    registration_email = f"registration.{suffix}@example.com"
    anonymous = Client()
    anonymous.request(
        "POST",
        "/auth/register",
        {
            "full_name": "Smoke Registration",
            "email": registration_email,
            "password": "Registration123!",
            "password_confirmation": "Registration123!",
            "role": "admin",
        },
        (201,),
    )
    anonymous.request("POST", "/auth/login", {"email": registration_email, "password": "Registration123!"}, (401,))
    _, users_body = admin.request("GET", "/users")
    registration = next(user for user in users_body["data"] if user["email"] == registration_email)
    assert registration["role"] == "readonly" and registration["pending_approval"] and not registration["is_active"]

    company_payload = {
        "name": f"Smoke Marine {suffix}",
        "type_id": company_type,
        "country": "Україна",
        "city": "Київ",
        "status_id": client_status,
        "website": "example.com",
        "description": "Кирилиця · Höflich · €",
    }
    _, body = admin.request("POST", "/companies", company_payload, (201,))
    company = body["data"]
    assert company["website"].startswith("https://")

    admin.request("POST", "/companies", company_payload, (409,))

    contact_payload = {
        "company_id": company["id"],
        "first_name": "Іван",
        "last_name": "Тестовий",
        "email": f"smoke.{suffix}@example.com",
        "phone": "+380 (44) 123-45-67",
        "source_id": contact_source,
        "source_detail": "SMM Hamburg 2026",
        "initiated_by_id": manager,
    }
    _, body = admin.request("POST", "/contacts", contact_payload, (201,))
    contact = body["data"]

    task_payload = {
        "company_id": company["id"],
        "name": "Smoke follow-up",
        "contact_date": "2026-08-06",
        "manager_id": manager,
        "contact_person_id": contact["id"],
        "description": "Initial description",
        "status_id": task_status,
        "outcome_status_id": outcome,
        "outcome_notes": "Initial outcome",
        "deadline": "2027-08-06T17:00:00+03:00",
        "reminder_lead_ids": [reminder],
    }
    _, body = admin.request("POST", "/tasks", task_payload, (201,))
    task = body["data"]
    stale_updated_at = task["updated_at"]

    task_payload.update(
        {
            "contact_date": "2026-08-07",
            "description": "Changed description",
            "outcome_notes": "Changed outcome",
            "updated_at": stale_updated_at,
        }
    )
    _, body = admin.request("PUT", f"/tasks/{task['id']}", task_payload)
    task = body["data"]
    admin.request("PUT", f"/tasks/{task['id']}", task_payload, (409,))

    _, body = admin.request("GET", f"/companies/{company['id']}")
    company = body["data"]
    assert company["last_contact_date"] == "2026-08-07"

    _, body = admin.request("GET", f"/tasks/{task['id']}/log")
    fields = {row["field_name"] for row in body["data"]}
    assert {"Contact Date", "Description", "Outcome notes"}.issubset(fields)

    _, ics = admin.request("GET", f"/tasks/{task['id']}/reminder.ics")
    assert b"BEGIN:VCALENDAR" in ics and b"BEGIN:VEVENT" in ics

    comment_status, body = admin.request("POST", f"/tasks/{task['id']}/comments", {"text": "Smoke comment"}, (201,))
    assert comment_status == 201 and body["data"]["id"] > 0

    readonly_email = f"readonly.{suffix}@example.com"
    _, body = admin.request(
        "POST",
        "/users",
        {
            "full_name": "Smoke Readonly",
            "email": readonly_email,
            "role": "readonly",
            "is_active": True,
            "delivery": "temporary_password",
            "temporary_password": "Readonly123!",
        },
        (201,),
    )
    readonly_user = body["data"]

    viewer = Client()
    viewer.login(readonly_email, "Readonly123!")
    viewer.request("POST", "/companies", company_payload | {"name": f"Forbidden {suffix}"}, (403,))

    admin.request(
        "PUT",
        f"/users/{admin_user['id']}",
        {
            "full_name": admin_user["full_name"],
            "role": "editor",
            "is_active": True,
            "updated_at": admin_user["updated_at"],
        },
        (409,),
    )

    admin.request("POST", f"/companies/{company['id']}/archive", {"archived": True, "updated_at": company["updated_at"]}, (409,))

    task_payload.update({"status_id": task_completed, "updated_at": task["updated_at"]})
    _, body = admin.request("PUT", f"/tasks/{task['id']}", task_payload)
    task = body["data"]

    _, body = admin.request("GET", "/audit?entity_type=Task&action=FIELD%20CHANGE&page=1")
    assert any(event["entity_id"] == task["id"] and event["field"] == "Contact Date" for event in body["data"])

    print(
        json.dumps(
            {
                "status": "ok",
                "company_id": company["id"],
                "contact_id": contact["id"],
                "task_id": task["id"],
                "readonly_user_id": readonly_user["id"],
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
