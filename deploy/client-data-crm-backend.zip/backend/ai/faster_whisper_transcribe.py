#!/usr/bin/env python3
"""Local GPU speech transcription for the CRM.

Prints one small JSON object to stdout. Audio and transcript content are never
written to logs by this runner.
"""

from __future__ import annotations

import argparse
import json
import re
import sys


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--model", default="large-v3-turbo")
    parser.add_argument("--cache-dir", required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--compute-type", default="float16")
    parser.add_argument("--beam-size", type=int, default=5)
    parser.add_argument("--language", default="")
    parser.add_argument("--initial-prompt", default="")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        from faster_whisper import WhisperModel

        model = WhisperModel(
            args.model,
            device=args.device,
            compute_type=args.compute_type,
            download_root=args.cache_dir,
        )
        segments, info = model.transcribe(
            args.input,
            language=args.language or None,
            beam_size=max(1, min(args.beam_size, 10)),
            vad_filter=True,
            vad_parameters={"min_silence_duration_ms": 350},
            condition_on_previous_text=False,
            initial_prompt=args.initial_prompt or None,
        )
        text = " ".join(segment.text.strip() for segment in segments if segment.text.strip())
        text = re.sub(r"\s+", " ", text).strip()
        print(json.dumps({"text": text, "language": getattr(info, "language", None)}, ensure_ascii=False))
        return 0
    except Exception as error:  # Content-free diagnostic for the PHP wrapper.
        print(json.dumps({"error": type(error).__name__}), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
